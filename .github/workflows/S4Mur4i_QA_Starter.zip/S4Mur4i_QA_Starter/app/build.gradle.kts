plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.s4mur4i.qa"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.s4mur4i.qa"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
