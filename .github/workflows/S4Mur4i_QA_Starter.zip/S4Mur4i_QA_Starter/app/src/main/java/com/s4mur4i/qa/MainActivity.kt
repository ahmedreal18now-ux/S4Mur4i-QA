package com.s4mur4i.qa

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var logView: TextView
    private lateinit var caseInput: EditText
    private lateinit var resultInput: EditText
    private lateinit var notesInput: EditText

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("s4m_qa", MODE_PRIVATE)

        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
        }
        scroll.addView(layout)
        setContentView(scroll)

        fun heading(text: String, size: Float = 20f) {
            layout.addView(TextView(this).apply {
                this.text = text
                textSize = size
                setTypeface(null, Typeface.BOLD)
                setPadding(0, dp(10), 0, dp(8))
            })
        }
        fun body(text: String) {
            layout.addView(TextView(this).apply {
                this.text = text
                textSize = 15f
                setPadding(0, dp(3), 0, dp(3))
            })
        }
        fun field(hint: String): EditText {
            return EditText(this).also {
                it.hint = hint
                it.textSize = 15f
                layout.addView(it, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
        }
        fun action(label: String, run: () -> Unit) {
            layout.addView(Button(this).apply {
                text = label
                setOnClickListener { run() }
            }, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        heading("S4Mur4i QA", 26f)
        body("أداة توثيق لاختبارات قيود الأجهزة المصرّح بها.")
        heading("معلومات بيئة الاختبار")
        body("الشركة المصنّعة: ${Build.MANUFACTURER}")
        body("الموديل: ${Build.MODEL}")
        body("إصدار Android: ${Build.VERSION.RELEASE}")
        body("SDK: ${Build.VERSION.SDK_INT}")
        body("Build fingerprint: ${Build.FINGERPRINT}")
        body("هذه بيانات وصفية عامة؛ لا تمثل تغييرًا أو تزويرًا لهوية الجهاز.")

        heading("تسجيل نتيجة اختبار")
        caseInput = field("اسم حالة الاختبار")
        resultInput = field("النتيجة: سمح / رفض / غير محسوم")
        notesInput = field("ملاحظات ورسالة التطبيق (بدون كلمات مرور أو بيانات شخصية)")

        action("حفظ السجل") { saveRecord() }
        action("مشاركة التقرير النصي") { shareReport() }
        action("مسح سجل الاختبارات المحلي") {
            prefs.edit().remove("log").apply()
            refreshLog()
        }

        heading("السجل المحفوظ")
        logView = TextView(this).apply {
            textSize = 14f
            setPadding(0, dp(6), 0, dp(12))
        }
        layout.addView(logView)
        refreshLog()
    }

    private fun saveRecord() {
        val caseName = caseInput.text.toString().trim()
        val result = resultInput.text.toString().trim()
        val notes = notesInput.text.toString().trim()
        if (caseName.isEmpty() || result.isEmpty()) {
            if (caseName.isEmpty()) caseInput.error = "اكتب اسم الحالة"
            if (result.isEmpty()) resultInput.error = "اكتب النتيجة"
            return
        }
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val record = "[$stamp] الحالة: $caseName | النتيجة: $result | ملاحظات: $notes"
        val old = prefs.getString("log", "") ?: ""
        prefs.edit().putString("log", if (old.isBlank()) record else "$old\n$record").apply()
        caseInput.text.clear()
        resultInput.text.clear()
        notesInput.text.clear()
        refreshLog()
    }

    private fun refreshLog() {
        if (::logView.isInitialized) {
            logView.text = prefs.getString("log", "").takeUnless { it.isNullOrBlank() }
                ?: "لا توجد سجلات حتى الآن."
        }
    }

    private fun reportText(): String {
        return "S4Mur4i QA Report\n" +
            "Manufacturer: ${Build.MANUFACTURER}\n" +
            "Model: ${Build.MODEL}\n" +
            "Android: ${Build.VERSION.RELEASE}\n" +
            "SDK: ${Build.VERSION.SDK_INT}\n" +
            "Build fingerprint: ${Build.FINGERPRINT}\n\n" +
            "Test records:\n${prefs.getString("log", "No records")}\n\n" +
            "Scope note: This report records observations only; it does not prove server-side identity or a bypass."
    }

    private fun shareReport() {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "S4Mur4i QA Test Report")
            putExtra(Intent.EXTRA_TEXT, reportText())
        }
        startActivity(Intent.createChooser(intent, "مشاركة تقرير S4Mur4i QA"))
    }
}
